#include "HomeScene.h"
#include "MyUtility.h"
#include "RunningScene.h"
#include "SimpleAudioEngine.h"
#include "ui/CocosGUI.h"

USING_NS_CC;

Scene* Home::createScene()
{
	return Home::create();
}

// Print useful error message instead of segfaulting when files are not there
static void problemLoading(const char* filename)
{
	printf("Error while loading: %s\n", filename);
}

// On "init" you need to initialize your instance
bool Home::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Scene::init())
	{
		return false;
	}

	auto visibleSize = Director::getInstance()->getVisibleSize();

	//////////////////////////////
	// 2. add a menu item with "EXIT" image, which is clicked to quit the program, you may modify it

	// add a "close" icon to exit the progress. it's an autorelease object
	auto closeItem = MenuItemImage::create("CloseNormal.png", "CloseSelected.png", CC_CALLBACK_1(Home::menuCloseCallback, this));
	if (closeItem == nullptr || closeItem->getContentSize().width <= 0 || closeItem->getContentSize().height <= 0)
	{
		problemLoading("'CloseNormal.png' and 'CloseSelected.png'");
	}
	else
	{
		float x = visibleSize.width - closeItem->getContentSize().width / 2;
		float y = closeItem->getContentSize().height / 2;
		closeItem->setPosition(Vec2(x, y));
	}

	// Create menu, it's an autorelease object
	auto menuClose = Menu::create(closeItem, NULL);
	menuClose->setPosition(Vec2::ZERO);
	this->addChild(menuClose, 1);

	//////////////////////////////
	// 3. add your codes below...

	// ������ǩ
	auto label = Label::createWithSystemFont(MyUtility::gbk2utf8("��    ��"), "����", 48);
	label->setPosition(visibleSize.width / 2, 3 * visibleSize.height / 4);
	label->setTextColor(Color4B::BLUE);
	label->enableShadow(Color4B::WHITE, Size(2, -2));
	this->addChild(label, 1);

	// ����˵����ǩ
	auto label2 = Label::createWithSystemFont(MyUtility::gbk2utf8("��ʾ��ʹ�÷������ WASD �����ƶ�"), "������", 20);
	label2->setPosition(visibleSize.width / 2, label2->getContentSize().height / 2 + 15);
	label2->setTextColor(Color4B::GRAY);
	this->addChild(label2, 1);

	// ������ʼ��Ϸ�˵�
	auto menuLabel = Label::createWithSystemFont(MyUtility::gbk2utf8("��ʼ��Ϸ"), "������", 24);
	menuLabel->setTextColor(Color4B::GRAY);
	menuLabel->enableBold();
	auto menuItemLabel = MenuItemLabel::create(menuLabel, [](Ref* pSender) { Director::getInstance()->replaceScene(Maze::createScene()); });
	menuItemLabel->setPosition(visibleSize.width / 2, visibleSize.height / 3);
	auto menuStart = Menu::createWithItem(menuItemLabel);
	menuStart->setPosition(Vec2::ZERO);
	this->addChild(menuStart, 1);

	return true;
}

void Home::menuCloseCallback(Ref* pSender)
{
	// Close the cocos2d-x game scene and quit the application
	Director::getInstance()->end();

	/* To navigate back to native iOS screen(if present) without quitting the application,
	do not use Director::getInstance()->end() as given above, instead trigger a custom event created in RootViewController.mm as below */

	// EventCustom customEndEvent("game_scene_close_event");
	// _eventDispatcher->dispatchEvent(&customEndEvent);
}
