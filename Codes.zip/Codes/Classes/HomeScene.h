#ifndef __HOMESCENE_H__
#define __HOMESCENE_H__

#include "cocos2d.h"

class Home :public cocos2d::Scene
{
public:
	static cocos2d::Scene* createScene();

	virtual bool init();

	void menuCloseCallback(cocos2d::Ref* pSender);

	// Implement the "static create()" method manually
	CREATE_FUNC(Home);
};

#endif // !__HOMESCENE_H__
