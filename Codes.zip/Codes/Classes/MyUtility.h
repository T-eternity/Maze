#ifndef __MY_UTILITY_H__
#define __MY_UTILITY_H__


#include <string>
#include "cocos2d.h"

class MyUtility
{
public:
	static std::string gbk2utf8(const std::string& text)
	{
#if(CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
		{
			std::wstring tes = [=]()
			{
				setlocale(LC_ALL, "chs");
				const char* _Sourse = text.c_str();
				size_t _Dsize = text.size() + 1;
				wchar_t* _Dest = new wchar_t[_Dsize];
				wmemset(_Dest, 0, _Dsize);
				mbstowcs(_Dest, _Sourse, _Dsize);
				std::wstring result = _Dest;
				delete[] _Dest;
				setlocale(LC_ALL, "C");
				return result;
			}();

			int asciSize = WideCharToMultiByte(CP_UTF8, 0, tes.c_str(), tes.size(), nullptr, 0, nullptr, nullptr);
			if (asciSize == ERROR_NO_UNICODE_TRANSLATION || asciSize == 0)
			{
				return std::string();
			}

			char* resultString = new char[asciSize];
			int conveResult = WideCharToMultiByte(CP_UTF8, 0, tes.c_str(), tes.size(), resultString, asciSize, nullptr, nullptr);

			if (conveResult != asciSize)
			{
				return std::string();
			}

			std::string buffer = "";
			buffer.append(resultString, asciSize);
			delete[] resultString;
			return buffer;

#else
		return text;
#endif
		}
	}
};


#endif // !__MY_UTILITY_H__
