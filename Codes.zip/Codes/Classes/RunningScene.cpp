#include "HomeScene.h"
#include "MyUtility.h"
#include "RunningScene.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

Scene* Maze::createScene()
{
	return Maze::create();
}

// On "init" you need to initialize your instance
bool Maze::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Scene::init())
	{
		return false;
	}

	auto visibleSize = Director::getInstance()->getVisibleSize();

	//////////////////////////////
	// 2. add your codes below...

	// ��������
	auto background = Sprite::create("Background.png");
	background->setPosition(visibleSize / 2);
	this->addChild(background, -1);

	// ������ǩ
	auto label = Label::createWithSystemFont(MyUtility::gbk2utf8("��    ��"), "����", 48);
	label->setPosition(visibleSize.width / 2, 7 * visibleSize.height / 8);
	label->setTextColor(Color4B::BLUE);
	label->enableShadow(Color4B::WHITE, Size(2, -2));
	this->addChild(label, 1);

	// �ص���ҳ�˵�
	auto menuLabel = Label::createWithSystemFont(MyUtility::gbk2utf8("��ҳ"), "������", 24);
	menuLabel->setTextColor(Color4B::GRAY);
	menuLabel->enableBold();
	auto menuItemLabel = MenuItemLabel::create(menuLabel, [this](Ref* pSender) {
		SpriteFrameCache::getInstance()->removeSpriteFrames();
		this->unschedule(schedule_selector(Maze::myUpdate));
		this->unschedule(schedule_selector(Maze::showPathUpdate));
		_eventDispatcher->removeEventListener(this->listenerKeyboard);
		Director::getInstance()->replaceScene(Home::createScene()); });
	menuItemLabel->setPosition(menuLabel->getContentSize().width / 2 + 5, visibleSize.height - menuLabel->getContentSize().height / 2 - 8);
	auto menuHome = Menu::createWithItem(menuItemLabel);
	menuHome->setPosition(Vec2::ZERO);
	this->addChild(menuHome, 1);

	// ���¿�ʼ�˵�
	auto menuLabel2 = Label::createWithSystemFont(MyUtility::gbk2utf8("���¿�ʼ"), "������", 24);
	menuLabel2->setTextColor(Color4B::GRAY);
	menuLabel2->enableBold();
	auto menuItemLabel2 = MenuItemLabel::create(menuLabel2, [this](Ref* pSender) {
		SpriteFrameCache::getInstance()->removeSpriteFrames();
		this->unschedule(schedule_selector(Maze::myUpdate));
		this->unschedule(schedule_selector(Maze::showPathUpdate));
		_eventDispatcher->removeEventListener(this->listenerKeyboard);
		Director::getInstance()->replaceScene(Maze::createScene()); });
	menuItemLabel2->setPosition(visibleSize.width / 2, visibleSize.height / 8);
	auto menuReStart = Menu::createWithItem(menuItemLabel2);
	menuReStart->setPosition(Vec2::ZERO);
	this->addChild(menuReStart, 1);

	// ��ʼ������
	int arr[] = { 25,49,99 };
	mapSize = arr[random() % 3];
	Map.resize(mapSize);

	// �����Թ�
	int temp = random() % 3;
	switch (temp)
	{
	case 0:		// DFS ����
		for (auto& cols : Map) cols.resize(mapSize, State::WALL);
		DFS_generator();
		break;
	case 1:		// ��� Prim ����
		for (auto& cols : Map) cols.resize(mapSize, State::WALL);
		Prim_generator();
		break;
	case 2:		// ʮ�ַָ�����
		for (auto& cols : Map) cols.resize(mapSize, State::PATH);
		Division_generator();
		break;
	}

	// ������ںͳ���
	start = Vec2(0, mapSize - 2);
	end = Vec2(mapSize - 1, 1);
	Map[start.x][start.y] = Map[end.x][end.y] = State::PATH;
	spritePos = start;

	// Ѱ·������Ѱ·������洢
	A_find(end, start);

	// ���Ӿ���֡����
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("Wall.png", Rect(0, 0, 20, 20)), "Wall");
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("Grass.png", Rect(0, 0, 10, 10)), "Grass");
	SpriteFrameCache::getInstance()->addSpriteFrame(SpriteFrame::create("mini.png", Rect(0, 0, 3, 3)), "Mini");

	// �Թ����Ӵ�����
	vLeftDown = Vec2(visibleSize.width / 4, visibleSize.height / 4 + cellSize / 2);
	vWidthHeight = Vec2(visibleSize.width / 2, visibleSize.height / 2 - cellSize);

	// ��ͼ��
	mapLayer = LayerColor::create(Color4B(0, 0, 0, 0), mapSize * cellSize + grassSize * 2, mapSize * cellSize + grassSize * 2);
	mapLayer->setPosition(vLeftDown);
	this->addChild(mapLayer, -2);

	// ��ͼ������Ԫ��
	// ���Ӳ�
	for (auto i = 0; i < mapLayer->getContentSize().height - 1; i += grassSize)
	{
		auto grass1 = Sprite::createWithSpriteFrameName("Grass");
		auto grass2 = Sprite::createWithSpriteFrameName("Grass");
		grass1->setPosition(i + grassSize / 2, grassSize / 2);
		grass2->setPosition(i + grassSize / 2, mapLayer->getContentSize().height - grassSize / 2);
		mapLayer->addChild(grass1);
		mapLayer->addChild(grass2);
	}
	for (auto i = 0; i < mapLayer->getContentSize().height - 1; i += grassSize)
	{
		auto grass3 = Sprite::createWithSpriteFrameName("Grass");
		auto grass4 = Sprite::createWithSpriteFrameName("Grass");
		grass3->setPosition(grassSize / 2, i + grassSize / 2);
		grass4->setPosition(mapLayer->getContentSize().width - grassSize / 2, i + grassSize / 2);
		mapLayer->addChild(grass3);
		mapLayer->addChild(grass4);
	}
	// ����ǽ
	for (int i = 0; i < mapSize; ++i)
	{
		for (int j = 0; j < mapSize; ++j)
		{
			if (Map[i][j] == State::WALL)
			{
				auto wall = Sprite::createWithSpriteFrameName("Wall");
				wall->setPosition(i * cellSize + cellSize / 2 + grassSize, mapLayer->getContentSize().height - j * cellSize - cellSize / 2 - grassSize);
				mapLayer->addChild(wall);
			}
		}
	}
	// ���
	auto x = start.x * cellSize + cellSize / 2 + grassSize;
	auto y = mapLayer->getContentSize().height - start.y * cellSize - cellSize / 2 - grassSize;
	auto inLabel = Label::createWithSystemFont(MyUtility::gbk2utf8("��"), "΢���ź�", 16);
	inLabel->setColor(Color3B::RED);
	inLabel->setPosition(x, y);
	inLabel->enableBold();
	mapLayer->addChild(inLabel, -1);
	// ����
	sprite = Sprite::create("Sprite.png");
	sprite->setPosition(x, y);
	mapLayer->addChild(sprite, 0);
	// ����
	x = end.x * cellSize + cellSize / 2 + grassSize;
	y = mapLayer->getContentSize().height - end.y * cellSize - cellSize / 2 - grassSize;
	auto outLabel = Label::createWithSystemFont(MyUtility::gbk2utf8("��"), "΢���ź�", 16);
	outLabel->setColor(Color3B::GREEN);
	outLabel->setPosition(x, y);
	inLabel->enableBold();
	mapLayer->addChild(outLabel, -1);

	// mini ��ͼ
	auto miniMap = Sprite::create("miniMap.png");
	miniMap->setPosition(visibleSize.width - 1, 0);
	miniMap->setAnchorPoint(Vec2(1, 0));
	this->addChild(miniMap);
	// mini ����
	// start
	x = (cellSize / 2 + grassSize) * miniMap->getContentSize().width / mapLayer->getContentSize().width;
	y = (3 * cellSize / 2 + grassSize) * miniMap->getContentSize().height / mapLayer->getContentSize().height;
	auto miniStart = Sprite::createWithSpriteFrameName("Mini");
	miniStart->setColor(Color3B::RED);
	miniStart->setPosition(x, y);
	miniMap->addChild(miniStart);
	// end
	x = miniMap->getContentSize().width - (cellSize / 2 + grassSize) * miniMap->getContentSize().width / mapLayer->getContentSize().width;
	y = miniMap->getContentSize().height - (3 * cellSize / 2 + grassSize) * miniMap->getContentSize().height / mapLayer->getContentSize().height;
	auto miniEnd = Sprite::createWithSpriteFrameName("Mini");
	miniEnd->setColor(Color3B::GREEN);
	miniEnd->setPosition(x, y);
	miniMap->addChild(miniEnd);
	// sprite
	auto miniSprite = Sprite::createWithSpriteFrameName("Mini");
	miniSprite->setColor(Color3B::YELLOW);
	miniMap->addChild(miniSprite);
	setMiniPos = [this, miniSprite, miniMap]()
	{
		auto x = sprite->getPosition().x * miniMap->getContentSize().width / mapLayer->getContentSize().width;
		auto y = sprite->getPosition().y * miniMap->getContentSize().height / mapLayer->getContentSize().height;
		miniSprite->setPosition(x, y);
	};
	setMiniPos();

	// �������̼����������÷�������� WASD �����߷���
	listenerKeyboard = EventListenerKeyboard::create();
	listenerKeyboard->onKeyPressed = [this](EventKeyboard::KeyCode kcode, Event*)
	{
		int i = 0;
		switch (kcode)
		{
		case (EventKeyboard::KeyCode::KEY_W):
		case EventKeyboard::KeyCode::KEY_UP_ARROW:
			this->dir = Direction::UP;
			this->isUpdata = true;
			i = 0;
			for (; i < 4; ++i)
				if (keyStack[i] == 0 || keyStack[i] == 2) break;
			if (keyStack[i] == 0) keyStack[i] = 2;
			else
			{
				for (; i < 3; ++i)
				{
					if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
					else break;
				}
				keyStack[i] = 2;
			}
			break;

		case (EventKeyboard::KeyCode::KEY_A):
		case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
			this->dir = Direction::LEFT;
			this->isUpdata = true;
			i = 0;
			for (; i < 4; ++i)
				if (keyStack[i] == 0 || keyStack[i] == 1) break;
			if (keyStack[i] == 0) keyStack[i] = 1;
			else
			{
				for (; i < 3; ++i)
				{
					if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
					else break;
				}
				keyStack[i] = 1;
			}
			break;

		case (EventKeyboard::KeyCode::KEY_S):
		case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
			this->dir = Direction::DOWN;
			this->isUpdata = true;
			i = 0;
			for (; i < 4; ++i)
				if (keyStack[i] == 0 || keyStack[i] == 4) break;
			if (keyStack[i] == 0) keyStack[i] = 4;
			else
			{
				for (; i < 3; ++i)
				{
					if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
					else break;
				}
				keyStack[i] = 4;
			}
			break;

		case (EventKeyboard::KeyCode::KEY_D):
		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
			this->dir = Direction::RIGHT;
			this->isUpdata = true;
			i = 0;
			for (; i < 4; ++i)
				if (keyStack[i] == 0 || keyStack[i] == 3) break;
			if (keyStack[i] == 0) keyStack[i] = 3;
			else
			{
				for (; i < 3; ++i)
				{
					if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
					else break;
				}
				keyStack[i] = 3;
			}
			break;
		}
	};
	listenerKeyboard->onKeyReleased = [this](EventKeyboard::KeyCode kcode, Event*)
	{
		int i = 0;
		switch (kcode)
		{
		case (EventKeyboard::KeyCode::KEY_W):
		case EventKeyboard::KeyCode::KEY_UP_ARROW:
			for (; i < 4; ++i)
				if (keyStack[i] == 2) break;
			for (; i < 3; ++i)
			{
				if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
				else break;
			}
			keyStack[i--] = 0;
			break;

		case (EventKeyboard::KeyCode::KEY_A):
		case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
			for (; i < 4; ++i)
				if (keyStack[i] == 1) break;
			for (; i < 3; ++i)
			{
				if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
				else break;
			}
			keyStack[i--] = 0;
			break;

		case (EventKeyboard::KeyCode::KEY_S):
		case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
			for (; i < 4; ++i)
				if (keyStack[i] == 4) break;
			for (; i < 3; ++i)
			{
				if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
				else break;
			}
			keyStack[i--] = 0;
			break;

		case (EventKeyboard::KeyCode::KEY_D):
		case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
			for (; i < 4; ++i)
				if (keyStack[i] == 3) break;
			for (; i < 3; ++i)
			{
				if (keyStack[i + 1] != 0) keyStack[i] = keyStack[i + 1];
				else break;
			}
			keyStack[i--] = 0;
			break;
		}
		if (i < 0) this->isUpdata = false;
		else
		{
			switch (keyStack[i])
			{
			case 1:
				dir = Direction::LEFT;
				break;
			case 2:
				dir = Direction::UP;
				break;
			case 3:
				dir = Direction::RIGHT;
				break;
			case 4:
				dir = Direction::DOWN;
				break;
			}
		}
	};
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listenerKeyboard, this);

	schedule(schedule_selector(Maze::myUpdate), 0.1f);
	schedule(schedule_selector(Maze::showPathUpdate), 1.0f);

	//// ���Լ����������ڲ鿴��ͼ
	//auto listener = EventListenerTouchOneByOne::create();
	//listener->onTouchBegan = [](Touch*, Event*) { return true; };
	//listener->onTouchMoved = [mapLayer](Touch* touch, Event*) {
	//	auto p1 = touch->getPreviousLocation();
	//	auto p2 = touch->getLocation();
	//	auto dp = p2 - p1;
	//	mapLayer->setPosition(mapLayer->getPosition() + dp);
	//};
	//_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, mapLayer);

	return true;
}

void Maze::showPathUpdate(float)
{
	if (aPath.empty())
	{
		unschedule(schedule_selector(Maze::showPathUpdate));
		return;
	}
	auto p = *aPath.begin();
	aPath.pop_front();
	auto sprite = Sprite::createWithSpriteFrameName("Mini");
	sprite->setPosition(p.x * cellSize + cellSize / 2 + grassSize, mapLayer->getContentSize().height - p.y * cellSize - cellSize / 2 - grassSize);
	sprite->setColor(Color3B::YELLOW);
	sprite->setScale(1.2f);
	mapLayer->addChild(sprite, -1);
}

void Maze::myUpdate(float)
{
	if (!this->isUpdata) return;
	auto mapLayerPos = mapLayer->getPosition();
	auto dp = sprite->getPosition() + mapLayerPos - vLeftDown;
	switch (this->dir)
	{
	case Direction::UP:
		if (spritePos.y - 1 < 0) return;
		if (Map[spritePos.x][spritePos.y - 1] == State::WALL) return;
		if (dp.y >= vWidthHeight.y / 2 && mapLayerPos.y + mapLayer->getContentSize().height > vLeftDown.y + vWidthHeight.y)
			mapLayer->runAction(MoveBy::create(0.05f, Vec2(0, -cellSize)));
		sprite->runAction(MoveBy::create(0.05f, Vec2(0, cellSize)));
		--spritePos.y;
		break;

	case Direction::LEFT:
		if (spritePos.x - 1 < 0) return;
		if (Map[spritePos.x - 1][spritePos.y] == State::WALL) return;
		if (dp.x <= vWidthHeight.x / 2 && mapLayerPos.x < vLeftDown.x) mapLayer->runAction(MoveBy::create(0.05f, Vec2(cellSize, 0)));
		sprite->runAction(MoveBy::create(0.05f, Vec2(-cellSize, 0)));
		--spritePos.x;
		break;

	case Direction::RIGHT:
		if (spritePos.x + 1 >= mapSize) return;
		if (Map[spritePos.x + 1][spritePos.y] == State::WALL) return;
		if (dp.x >= vWidthHeight.x / 2 && mapLayerPos.x + mapLayer->getContentSize().width > vLeftDown.x + vWidthHeight.x) mapLayer->runAction(MoveBy::create(0.05f, Vec2(-cellSize, 0)));
		sprite->runAction(MoveBy::create(0.05f, Vec2(cellSize, 0)));
		++spritePos.x;
		break;

	case Direction::DOWN:
		if (spritePos.y + 1 >= mapSize) return;
		if (Map[spritePos.x][spritePos.y + 1] == State::WALL) return;
		if (dp.y <= vWidthHeight.y / 2 && mapLayerPos.y < vLeftDown.y) mapLayer->runAction(MoveBy::create(0.05f, Vec2(0, cellSize)));
		sprite->runAction(MoveBy::create(0.05f, Vec2(0, -cellSize)));
		++spritePos.y;
		break;
	}
	setMiniPos();
	if (spritePos == end)
	{
		SpriteFrameCache::getInstance()->removeSpriteFrames();
		this->unschedule(schedule_selector(Maze::myUpdate));
		this->unschedule(schedule_selector(Maze::showPathUpdate));
		auto gameOver = Sprite::create("GameOver.png");
		gameOver->setPosition(Director::getInstance()->getVisibleSize() / 2);
		this->addChild(gameOver, 5);
	}
}

// �Թ������㷨֮ DFS
void Maze::DFS_generator()
{
	// ����ջ����
	std::stack<Vec2> sp;
	// ���巽������
	std::vector<std::vector<int>> dir{ {1,0},{-1,0},{0,1},{0,-1} };
	// Ҫ�����Ϊ����
	Vec2 temp((random() % (mapSize - 2) + 1) | 1, (random() % (mapSize - 2) + 1) | 1);
	sp.push(temp);
	// �������������Թ�
	while (!sp.empty())
	{
		if (Map[temp.x][temp.y] != State::PATH) Map[temp.x][temp.y] = State::PATH;
		// ������ҷ���
		std::random_shuffle(dir.begin(), dir.end());
		int i = 0;
		for (; i < 4; ++i)
		{
			if (temp.x + 2 * dir[i][0] >= 1 && temp.x + 2 * dir[i][0] <= mapSize - 2 && temp.y + 2 * dir[i][1] >= 1 && temp.y + 2 * dir[i][1] <= mapSize - 2
				&& Map[temp.x + 2 * dir[i][0]][temp.y + 2 * dir[i][1]] == State::WALL)
			{
				Map[temp.x + dir[i][0]][temp.y + dir[i][1]] = State::PATH;
				temp.x += 2 * dir[i][0];
				temp.y += 2 * dir[i][1];
				sp.push(temp);
				break;
			}
		}
		if (i == 4) sp.pop();
		if (!sp.empty()) temp = sp.top();
	}
}

// �Թ������㷨֮��� Prim
void Maze::Prim_generator()
{
	// ����ǽ����ͨ·���Թ���������Ϊͨ·
	for (int i = 1; i <= mapSize - 2; i += 2)
		for (int j = 1; j <= mapSize - 2; j += 2)
			Map[i][j] = State::PATH;
	// ά��һ��ǽ����
	std::vector<Vec2> vp;
	// �������һ��ͨ·
	Vec2 temp((random() % (mapSize - 2) + 1) | 1, (random() % (mapSize - 2) + 1) | 1);
	// ����Χǽ��ջ
	if (temp.x - 1 >= 2) vp.push_back(Vec2(temp.x - 1, temp.y));
	if (temp.x + 1 <= mapSize - 3) vp.push_back(Vec2(temp.x + 1, temp.y));
	if (temp.y - 1 >= 2) vp.push_back(Vec2(temp.x, temp.y - 1));
	if (temp.y + 1 <= mapSize - 3) vp.push_back(Vec2(temp.x, temp.y + 1));
	// ��Ǹ�ͨ·
	Map[temp.x][temp.y] = State::FLAG;
	int pos = 0;
	// �������������Թ�
	while (!vp.empty())
	{
		// ��ǽ���������ѡȡһ��ǽ
		pos = random() % vp.size();
		temp = vp[pos];
		// ��¼��ǽ�Ƿ��ͨ
		bool flag = false;
		// ���� if else �ж�ǽ������ͨ·�����һ������£����ж��Ƿ��ͨ
		if (Map[temp.x + 1][temp.y] == State::WALL)
		{
			if (Map[temp.x][temp.y - 1] != Map[temp.x][temp.y + 1])
			{
				Map[temp.x][temp.y] = State::PATH;
				// ���¼����ͨ·���б��
				if (Map[temp.x][temp.y - 1] == State::FLAG) { Map[temp.x][temp.y + 1] = State::FLAG; ++temp.y; }
				else { Map[temp.x][temp.y - 1] = State::FLAG; --temp.y; }
				flag = true;
			}
		}
		else
		{
			if (Map[temp.x - 1][temp.y] != Map[temp.x + 1][temp.y])
			{
				Map[temp.x][temp.y] = State::PATH;
				// ���¼����ͨ·���б��
				if (Map[temp.x - 1][temp.y] == State::FLAG) { Map[temp.x + 1][temp.y] = State::FLAG; ++temp.x; }
				else { Map[temp.x - 1][temp.y] = State::FLAG; --temp.x; }
				flag = true;
			}
		}
		// �����ͨ��ǽ�����������ͨ·��Χ��ǽ������
		if (flag)
		{
			if (temp.x - 1 >= 2 && Map[temp.x - 1][temp.y] == State::WALL) vp.push_back(Vec2(temp.x - 1, temp.y));
			if (temp.x + 1 <= mapSize - 3 && Map[temp.x + 1][temp.y] == State::WALL) vp.push_back(Vec2(temp.x + 1, temp.y));
			if (temp.y - 1 >= 2 && Map[temp.x][temp.y - 1] == State::WALL) vp.push_back(Vec2(temp.x, temp.y - 1));
			if (temp.y + 1 <= mapSize - 3 && Map[temp.x][temp.y + 1] == State::WALL) vp.push_back(Vec2(temp.x, temp.y + 1));
		}
		// �Ƴ���ǽ
		vp[pos] = *(vp.end() - 1);
		vp.pop_back();
	}
	// ������ǵ�ͨ·��ԭ
	for (auto& v1 : Map)
		for (auto& v2 : v1)
			if (v2 == State::FLAG) v2 = State::PATH;
}

// �Թ������㷨֮ʮ�ַָ�
void Maze::Division_generator()
{
	struct Point4
	{
		int x1, x2;
		int y1, y2;
		Point4(int _x1, int _x2, int _y1, int _y2) :x1(_x1), x2(_x2), y1(_y1), y2(_y2) {}
	};
	// ���ܽ�ǽ
	for (int i = 0; i < mapSize; ++i) Map[i][0] = Map[i][mapSize - 1] = State::WALL;
	for (int j = 1; j < mapSize - 1; ++j) Map[0][j] = Map[mapSize - 1][j] = State::WALL;
	// ����ջ����
	std::stack<Point4> sp;
	// ���巽������
	std::vector<int> dir{ 0,1,2,3 };
	// Ҫ�����Ϊ����
	Point4 temp(1, mapSize - 2, 1, mapSize - 2);
	sp.push(temp);
	// �������������Թ�
	while (!sp.empty())
	{
		sp.pop();
		if (temp.x2 - temp.x1 > 1 && temp.y2 - temp.y1 > 1)
		{
			int i = 0;
			int px = ((random() % (temp.x2 - temp.x1) + temp.x1 + 1) | 1) - 1;
			int py = ((random() % (temp.y2 - temp.y1) + temp.y1 + 1) | 1) - 1;
			while (px + i <= temp.x2 || px - i >= temp.x1 || py + i <= temp.y2 || py - i >= temp.y1)
			{
				if (px + i <= temp.x2) Map[px + i][py] = State::WALL;
				if (px - i >= temp.x1) Map[px - i][py] = State::WALL;
				if (py + i <= temp.y2) Map[px][py + i] = State::WALL;
				if (py - i >= temp.y1) Map[px][py - i] = State::WALL;
				++i;
			}
			// ���������ǽ�Ͽ�����Ҫ�󿪶�λ��������
			std::random_shuffle(dir.begin(), dir.end());
			for (int j = 0; j < 3; ++j)
			{
				if (dir[j] == 0)
				{
					int xx = (random() % (px - temp.x1) + temp.x1) | 1;
					Map[xx][py] = State::PATH;
				}
				else if (dir[j] == 1)
				{
					int xx = (random() % (temp.x2 - px) + px) | 1;
					Map[xx][py] = State::PATH;
				}
				else if (dir[j] == 2)
				{
					int yy = (random() % (py - temp.y1) + temp.y1) | 1;
					Map[px][yy] = State::PATH;
				}
				else if (dir[j] == 3)
				{
					int yy = (random() % (temp.y2 - py) + py) | 1;
					Map[px][yy] = State::PATH;
				}
			}
			// ����������������ջ
			sp.push(Point4(px + 1, temp.x2, py + 1, temp.y2));
			sp.push(Point4(temp.x1, px - 1, py + 1, temp.y2));
			sp.push(Point4(px + 1, temp.x2, temp.y1, py - 1));
			temp.x2 = px - 1;
			temp.y2 = py - 1;
			sp.push(temp);
		}
		else if (!sp.empty()) { temp = sp.top(); }
	}
}

void Maze::A_find(const Vec2& startPos, const Vec2& endPos)
{
	// �洢�ڵ�
	struct Node
	{
		Vec2 p2;
		int gVal, hVal, fVal;
		Node* parent;
		Node(const Vec2& _p2, int _g, int _h, Node* _p) :p2(_p2), gVal(_g), hVal(_h), fVal(_g + _h), parent(_p) {}
	};
	// �Ƚ� fVal
	struct Compare
	{
		bool operator ()(const Node* _n1, const Node* _n2) const { return _n1->fVal < _n2->fVal; }
	};

	// ���ڻ��ݵõ�·��
	Node* p_destNode = nullptr;
	// closeList & openList
	std::list<Node*> closeList;
	std::multiset<Node*, Compare> openList;

	// ���ڵ���� openList������ true ��Ϊ�ҵ�·��������
	auto pushOpenList = [&closeList, &openList, this, &p_destNode, &startPos, &endPos](const Vec2& _p2)
	{
		int gVal = 0;
		Node* par = nullptr;
		if (!closeList.empty()) { par = *(--closeList.end()); gVal = par->gVal + 1; }
		Node* temp = new Node(_p2, gVal, abs(_p2.x - endPos.x) + abs(_p2.y - endPos.y), par);
		if (_p2.x == endPos.x && _p2.y == endPos.y) p_destNode = temp;
		openList.insert(temp);
		temp = nullptr;
		return p_destNode == nullptr ? false : true;
	};
	// �� openList ��ȡ�� fVal ֵ��С�Ľڵ���� closeList
	auto getMinNode = [&openList, &closeList]
	{
		auto it = openList.begin();
		Vec2 ret = (*it)->p2;
		closeList.push_back(*it);
		openList.erase(it);
		return ret;
	};

	// ��ʼѰ·
	auto temp = startPos;
	pushOpenList(temp);
	Map[temp.x][temp.y] = State::FLAG;
	while (true)
	{
		// �� openList �� F ֵ��С�Ľڵ�ŵ� closeList ��
		temp = getMinNode();
		// ���� if ����Χͨ·���� openList
		if (temp.x - 1 >= 0 && Map[temp.x - 1][temp.y] == State::PATH)
		{
			Map[temp.x - 1][temp.y] = State::FLAG;
			if (pushOpenList(Vec2(temp.x - 1, temp.y))) break;
		}
		if (temp.y - 1 >= 0 && Map[temp.x][temp.y - 1] == State::PATH)
		{
			Map[temp.x][temp.y - 1] = State::FLAG;
			if (pushOpenList(Vec2(temp.x, temp.y - 1))) break;
		}
		if (temp.x + 1 <= mapSize - 1 && Map[temp.x + 1][temp.y] == State::PATH)
		{
			Map[temp.x + 1][temp.y] = State::FLAG;
			if (pushOpenList(Vec2(temp.x + 1, temp.y))) break;
		}
		if (temp.y + 1 <= mapSize - 1 && Map[temp.x][temp.y + 1] == State::PATH)
		{
			Map[temp.x][temp.y + 1] = State::FLAG;
			if (pushOpenList(Vec2(temp.x, temp.y + 1))) break;
		}
	}
	// ������ǵ�ͨ·��ԭ
	for (auto& v1 : Map)
		for (auto& v2 : v1)
			if (v2 == State::FLAG) v2 = State::PATH;
	// �ҵ����󣬻��ݵõ����·��
	while (p_destNode != nullptr)
	{
		aPath.push_back({ p_destNode->p2 });
		p_destNode = p_destNode->parent;
	}
	// ɾ�������յ�
	aPath.pop_front();
	aPath.pop_back();
	// �ͷ��ڴ�
	for (auto& no : openList) delete no;
	for (auto& no : closeList) delete no;
}
